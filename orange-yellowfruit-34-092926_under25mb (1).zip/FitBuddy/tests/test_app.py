import os

os.environ["MOCK_AI"] = "true"
os.environ["ADMIN_TOKEN"] = "test-token"

from fastapi.testclient import TestClient

from app.database import init_db
from app.main import app

init_db()
client = TestClient(app)


def test_health():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "FitBuddy" in response.text


def test_generate_api():
    response = client.post("/api/generate-workout", json={"username": "Test User", "user_id": "test-user", "age": 25, "weight": 70, "goal": "general wellness", "intensity": "medium"})
    assert response.status_code == 200
    data = response.json()
    assert data["user_id"] == "test-user"
    assert "DAY 1" in data["workout_plan"]
    assert data["nutrition_tip"]


def test_feedback_api():
    response = client.post("/api/submit-feedback", json={"user_id": "test-user", "feedback": "Add more gentle cardio and another recovery day."})
    assert response.status_code == 200
    assert response.json()["updated_plan"]


def test_admin_api():
    response = client.get("/api/users?token=test-token")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
