# FitBuddy

FitBuddy is a FastAPI web app that creates practical 7-day general fitness plans, nutrition or recovery tips, and feedback-based plan updates. It uses SQLite for persistence and can run with mock AI during development or Google Gemini when configured.

## Run on Windows

```powershell
python -m venv venv
venv\\Scripts\\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`. API documentation is available at `/docs`.

The default `.env` uses `MOCK_AI=true`, so no API key is needed. To use Gemini, set `GEMINI_API_KEY` and change `MOCK_AI=false`. The admin dashboard is at `/view-all-users` and uses the `ADMIN_TOKEN` value from `.env`.

Run tests with:

```powershell
pytest
```

For public deployment, add HTTPS, stronger authentication, CSRF protection, rate limiting, secure secret management, migrations, logging, monitoring, privacy controls, and professional review of health-related AI output.
