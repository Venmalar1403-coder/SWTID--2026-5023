from typing import Generator

from sqlalchemy import create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker
from sqlalchemy.types import Float, Integer, String, Text

from .config import get_settings


settings = get_settings()
connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    username: Mapped[str] = mapped_column(String(120))
    age: Mapped[int] = mapped_column(Integer)
    weight: Mapped[float] = mapped_column(Float)
    goal: Mapped[str] = mapped_column(String(80))
    intensity: Mapped[str] = mapped_column(String(20))


class Plan(Base):
    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    original_plan: Mapped[str] = mapped_column(Text)
    updated_plan: Mapped[str | None] = mapped_column(Text, nullable=True)
    nutrition_tip: Mapped[str] = mapped_column(Text)
    feedback: Mapped[str | None] = mapped_column(Text, nullable=True)


def init_db() -> None:
    Base.metadata.create_all(bind=engine)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def save_user(db: Session, *, user_id: str, username: str, age: int, weight: float, goal: str, intensity: str) -> User:
    user = db.scalar(select(User).where(User.user_id == user_id))
    if user:
        user.username, user.age, user.weight = username, age, weight
        user.goal, user.intensity = goal, intensity
    else:
        user = User(user_id=user_id, username=username, age=age, weight=weight, goal=goal, intensity=intensity)
        db.add(user)
    db.commit()
    db.refresh(user)
    return user


def save_plan(db: Session, *, user_id: str, original_plan: str, nutrition_tip: str) -> Plan:
    plan = db.scalar(select(Plan).where(Plan.user_id == user_id))
    if plan:
        plan.original_plan, plan.updated_plan, plan.feedback = original_plan, None, None
        plan.nutrition_tip = nutrition_tip
    else:
        plan = Plan(user_id=user_id, original_plan=original_plan, nutrition_tip=nutrition_tip)
        db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


def update_plan(db: Session, *, user_id: str, updated_plan: str, feedback: str) -> Plan | None:
    plan = get_plan(db, user_id)
    if not plan:
        return None
    plan.updated_plan, plan.feedback = updated_plan, feedback
    db.commit()
    db.refresh(plan)
    return plan


def get_user(db: Session, user_id: str) -> User | None:
    return db.scalar(select(User).where(User.user_id == user_id))


def get_plan(db: Session, user_id: str) -> Plan | None:
    return db.scalar(select(Plan).where(Plan.user_id == user_id))


def get_all_users(db: Session) -> list[User]:
    return list(db.scalars(select(User).order_by(User.id.desc())).all())


def get_all_plans(db: Session) -> list[Plan]:
    return list(db.scalars(select(Plan).order_by(Plan.id.desc())).all())


def delete_user(db: Session, user_id: str) -> bool:
    user, plan = get_user(db, user_id), get_plan(db, user_id)
    if not user:
        return False
    if plan:
        db.delete(plan)
    db.delete(user)
    db.commit()
    return True
