from pathlib import Path
from secrets import compare_digest

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from .config import get_settings
from .database import delete_user, get_all_plans, get_all_users, get_db, get_plan, get_user, save_plan, save_user, update_plan
from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .gemini_generator import generate_workout_gemini
from .schemas import FeedbackRequest, HealthResponse, PlanResponse, UserInput
from .updated_plan import update_workout_plan

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=BASE_DIR / "templates")
router = APIRouter()


def _admin_ok(request: Request) -> bool:
    session = request.scope.get("session", {})
    if session.get("admin_authenticated"):
        return True
    supplied = request.query_params.get("token", "")
    return bool(supplied) and compare_digest(supplied, get_settings().admin_token)


def _render_result(request: Request, user, workout_plan, nutrition_tip, updated_plan=None, message=None, error=None, status_code=200):
    return templates.TemplateResponse(request=request, name="result.html", context={"user": user, "workout_plan": workout_plan, "nutrition_tip": nutrition_tip, "updated_plan": updated_plan, "message": message, "error": error}, status_code=status_code)


def _generate_and_save(data: UserInput, db: Session) -> tuple[str, str]:
    workout = generate_workout_gemini(data.username, data.age, data.weight, data.goal, data.intensity)
    nutrition_tip = generate_nutrition_tip_with_flash(data.goal)
    save_user(db, user_id=data.user_id, username=data.username, age=data.age, weight=data.weight, goal=data.goal, intensity=data.intensity)
    save_plan(db, user_id=data.user_id, original_plan=workout, nutrition_tip=nutrition_tip)
    return workout, nutrition_tip


@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"error": None})


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout_form(request: Request, username: str = Form(...), user_id: str = Form(...), age: int = Form(...), weight: float = Form(...), goal: str = Form(...), intensity: str = Form(...), db: Session = Depends(get_db)):
    try:
        data = UserInput(username=username, user_id=user_id, age=age, weight=weight, goal=goal, intensity=intensity)
        workout, nutrition_tip = _generate_and_save(data, db)
        return _render_result(request, data, workout, nutrition_tip)
    except Exception as exc:
        return templates.TemplateResponse(request=request, name="index.html", context={"error": str(exc)}, status_code=400)


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback_form(request: Request, user_id: str = Form(...), feedback: str = Form(...), db: Session = Depends(get_db)):
    user, plan = get_user(db, user_id), get_plan(db, user_id)
    if not user or not plan:
        return _render_result(request, None, None, None, error="User ID not found. Generate a plan first.", status_code=404)
    try:
        request_data = FeedbackRequest(user_id=user_id, feedback=feedback)
        revised = update_workout_plan(plan.original_plan, request_data.feedback)
        update_plan(db, user_id=user_id, updated_plan=revised, feedback=request_data.feedback)
        return _render_result(request, user, plan.original_plan, plan.nutrition_tip, revised, "Your plan was updated successfully.")
    except Exception as exc:
        return _render_result(request, user, plan.original_plan, plan.nutrition_tip, error=str(exc), status_code=400)


@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, db: Session = Depends(get_db)):
    if not _admin_ok(request):
        return templates.TemplateResponse(request=request, name="admin_login.html", context={"error": None}, status_code=401)
    users = get_all_users(db)
    plans = {plan.user_id: plan for plan in get_all_plans(db)}
    return templates.TemplateResponse(request=request, name="all_users.html", context={"users": users, "plans": plans})


@router.post("/admin/login")
def admin_login(request: Request, token: str = Form(...)):
    if not compare_digest(token, get_settings().admin_token):
        return templates.TemplateResponse(request=request, name="admin_login.html", context={"error": "Invalid admin token."}, status_code=401)
    request.session["admin_authenticated"] = True
    return RedirectResponse("/view-all-users", status_code=303)


@router.post("/admin/delete/{user_id}")
def admin_delete_user(user_id: str, request: Request, db: Session = Depends(get_db)):
    if not _admin_ok(request):
        raise HTTPException(status_code=401, detail="Admin authentication required.")
    delete_user(db, user_id)
    return RedirectResponse("/view-all-users", status_code=303)


@router.get("/api/health", response_model=HealthResponse)
def health():
    return {"status": "ok", "ai_mode": "mock" if get_settings().mock_ai else "gemini"}


@router.post("/api/generate-workout", response_model=PlanResponse)
def generate_workout_api(data: UserInput, db: Session = Depends(get_db)):
    try:
        workout, nutrition_tip = _generate_and_save(data, db)
        return PlanResponse(user_id=data.user_id, username=data.username, goal=data.goal, intensity=data.intensity, workout_plan=workout, nutrition_tip=nutrition_tip)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/api/submit-feedback", response_model=PlanResponse)
def submit_feedback_api(data: FeedbackRequest, db: Session = Depends(get_db)):
    user, plan = get_user(db, data.user_id), get_plan(db, data.user_id)
    if not user or not plan:
        raise HTTPException(status_code=404, detail="User ID not found.")
    try:
        revised = update_workout_plan(plan.original_plan, data.feedback)
        update_plan(db, user_id=data.user_id, updated_plan=revised, feedback=data.feedback)
        return PlanResponse(user_id=user.user_id, username=user.username, goal=user.goal, intensity=user.intensity, workout_plan=plan.original_plan, nutrition_tip=plan.nutrition_tip, updated_plan=revised)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/api/users")
def users_api(request: Request, db: Session = Depends(get_db)):
    if not _admin_ok(request):
        raise HTTPException(status_code=401, detail="Admin authentication required.")
    plans = {plan.user_id: plan for plan in get_all_plans(db)}
    return JSONResponse([{"user_id": user.user_id, "username": user.username, "age": user.age, "weight": user.weight, "goal": user.goal, "intensity": user.intensity, "original_plan": plans[user.user_id].original_plan if user.user_id in plans else None, "updated_plan": plans[user.user_id].updated_plan if user.user_id in plans else None} for user in get_all_users(db)])
