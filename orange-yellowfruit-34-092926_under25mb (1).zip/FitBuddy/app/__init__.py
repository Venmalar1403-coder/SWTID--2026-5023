"""FitBuddy application package."""
