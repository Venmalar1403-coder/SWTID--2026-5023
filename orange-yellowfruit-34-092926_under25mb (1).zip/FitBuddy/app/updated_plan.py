from .config import get_settings
from .gemini_generator import _client, types


def _mock_update(original_plan: str, feedback: str) -> str:
    return f"""UPDATED FITBUDDY PLAN

USER FEEDBACK:
{feedback}

PLAN UPDATE:
The original 7-day structure has been adjusted to reflect the requested preference. Keep recovery days, progress gradually, and stop activities that cause pain.

ORIGINAL PLAN:
{original_plan}
"""


def update_workout_plan(original_plan: str, feedback: str) -> str:
    settings = get_settings()
    if settings.mock_ai:
        return _mock_update(original_plan, feedback)
    response = _client().models.generate_content(
        model=settings.workout_model,
        contents=f"Revise this general wellness workout plan according to the user's reasonable feedback. Keep a complete 7-day structure, at least one recovery day, warm-ups, cooldowns, simple instructions, and a safety note. Avoid medical diagnosis, medication advice, supplements, restrictive calorie targets, and extreme training.\n\nORIGINAL PLAN:\n{original_plan}\n\nUSER FEEDBACK:\n{feedback}",
        config=types.GenerateContentConfig(temperature=0.6, max_output_tokens=3500),
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty updated plan.")
    return text
