from .config import get_settings
from .gemini_generator import _client, types


def _mock_tip(goal: str) -> str:
    tips = {
        "weight loss": "Build balanced meals around vegetables, protein, whole grains, and water. Focus on consistent habits rather than restrictive eating.",
        "muscle gain": "Include a protein-rich food in regular meals and allow adequate recovery between challenging sessions.",
        "general wellness": "Stay hydrated, eat a variety of foods, sleep consistently, and include regular enjoyable movement.",
        "flexibility": "Include gentle mobility work regularly and move gradually through a comfortable range of motion.",
    }
    return tips.get(goal, tips["general wellness"])


def generate_nutrition_tip_with_flash(goal: str) -> str:
    settings = get_settings()
    if settings.mock_ai:
        return _mock_tip(goal)
    response = _client().models.generate_content(
        model=settings.tip_model,
        contents=f"Give one concise, practical nutrition or recovery tip for a person whose general fitness goal is {goal}. Keep it health-oriented, avoid restrictive eating, calorie targets, supplements, and medical advice. Use 2-4 sentences.",
        config=types.GenerateContentConfig(temperature=0.5, max_output_tokens=300),
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty nutrition tip.")
    return text
