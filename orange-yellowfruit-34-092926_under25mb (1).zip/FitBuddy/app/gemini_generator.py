from .config import get_settings

try:
    from google import genai
    from google.genai import types
except ImportError:
    genai = None
    types = None


def _mock_workout(username: str, goal: str, intensity: str) -> str:
    return f"""FITBUDDY 7-DAY WORKOUT PLAN

User: {username}
Goal: {goal.title()}
Intensity: {intensity.title()}

SAFETY NOTE: This general wellness template is not medical advice. Stop if you feel pain and seek qualified guidance when appropriate.

DAY 1 - FULL BODY
Warm-up: 5-10 minutes of easy movement.
Main workout: Bodyweight squats, incline push-ups, glute bridges, and an easy 10-20 minute walk. Do 2-3 comfortable sets.
Cooldown: Gentle stretching and relaxed breathing.

DAY 2 - CARDIO + CORE
15-25 minutes of comfortable cardio, followed by 2 sets each of dead bugs and bird dogs. Stretch gently afterward.

DAY 3 - RECOVERY
Easy walking, light mobility, and gentle stretching for 15-30 minutes. Keep the effort comfortable.

DAY 4 - LOWER BODY
Warm up, then do squats, supported reverse lunges, and glute bridges for 2-3 comfortable sets. Cool down gently.

DAY 5 - UPPER BODY
Incline push-ups, resistance-band rows if available, and light shoulder mobility for 2-3 sets. Finish with easy stretching.

DAY 6 - LIGHT CARDIO + MOBILITY
15-30 minutes of comfortable cardio and 5-10 minutes of mobility.

DAY 7 - REST / ACTIVE RECOVERY
Rest, sleep well, stay hydrated, and choose only gentle movement if comfortable.

PROGRESSION
Increase difficulty gradually. Do not force intensity or exercise through pain.
"""


def _client():
    settings = get_settings()
    if settings.mock_ai:
        return None
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to .env or set MOCK_AI=true.")
    if genai is None:
        raise RuntimeError("google-genai is not installed. Run: pip install -r requirements.txt")
    return genai.Client(api_key=settings.gemini_api_key)


def generate_workout_gemini(username: str, age: int, weight: float, goal: str, intensity: str) -> str:
    settings = get_settings()
    if settings.mock_ai:
        return _mock_workout(username, goal, intensity)
    response = _client().models.generate_content(
        model=settings.workout_model,
        contents=f"Create a clear, cautious 7-day general wellness workout plan for {username}, age {age}, weight {weight} kg, goal {goal}, intensity {intensity}. Include warm-ups, main workouts, cooldowns, recovery days, simple time or set ranges, and a safety note. Avoid medical advice, medication, restrictive calorie targets, and extreme exercise.",
        config=types.GenerateContentConfig(temperature=0.6, max_output_tokens=3000),
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty workout plan.")
    return text
